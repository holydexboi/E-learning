-- MariaDB dump 10.19  Distrib 10.11.4-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: elearning
-- ------------------------------------------------------
-- Server version	10.11.4-MariaDB-1~deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activations`
--

DROP TABLE IF EXISTS `activations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activations` (
  `id` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `valid` tinyint(1) DEFAULT 1,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activations`
--

LOCK TABLES `activations` WRITE;
/*!40000 ALTER TABLE `activations` DISABLE KEYS */;
INSERT INTO `activations` VALUES
('027ec666-00e0-4174-b9be-a5bc230aa5f8','m4QE16',0,'2023-12-03 15:44:51.350435'),
('02fb2134-c767-4849-9033-eafeaf267320','QhGRQT',0,'2023-12-20 10:42:36.053476'),
('13547a9c-2672-4e41-99ed-a4c84139ad54','-xVSWO',1,'2023-12-22 17:12:48.273906'),
('1bfb95aa-67cd-4a33-838d-27648e221eeb','YqonJF',1,'2023-12-22 17:12:14.278223'),
('1cf95b8b-06e7-4e11-9c91-8c54e1fd5323','b0PmFc',0,'2023-12-22 15:01:08.710499'),
('307d12aa-b144-410f-8e76-8bdfb3411cce','FFmknF',0,'2023-12-20 10:21:42.376795'),
('3cd240e2-dc46-4373-92da-04275ca8aa08','4RfQ_r',1,'2023-12-03 15:45:38.587267'),
('468c47c7-b71f-4b89-8e8c-d00427c95ed4','FERFtH',0,'2023-12-15 10:32:27.098337'),
('4fdc8097-93b7-431d-b280-3fcc387c950c','Jk_3Kc',0,'2023-11-13 11:51:27.367562'),
('568834d7-0853-459c-8976-06e8290f6620','_dm8Ru',0,'2023-12-20 11:22:50.564396'),
('60f1eccd-696c-486b-a21e-af9f9e071c9a','G5YMy9',1,'2023-12-22 17:13:05.224942'),
('61775497-9679-412e-84ab-e50380808ff3','aONLHJ',1,'2023-12-22 17:12:20.702589'),
('62db25c5-5946-44cf-af26-47d19ffb4cce','-14KIp',1,'2023-12-22 17:13:12.646995'),
('642dd3fa-ec36-4f75-9190-ac4f6e46d250','y7TZRu',0,'2023-12-20 11:22:44.568340'),
('657762f4-c67b-4a76-a573-6d057cea8b6f','ab7kT3',1,'2023-12-22 17:12:36.153155'),
('76270453-86aa-4aa8-8880-207877d6dd61','gY0t-f',1,'2023-11-13 11:51:19.900058'),
('7909bf0a-8213-42b9-bc3f-2a96e10020cf','2DfzlE',1,'2023-11-14 13:38:43.742284'),
('7b73a8ef-252f-412b-b2b1-e28ce74f9b75','Cd75B9',1,'2023-12-22 17:12:42.503382'),
('7d7819a1-bf4a-4e6e-b281-9d32f432ad07','RCMeA_',0,'2023-12-22 17:11:58.479882'),
('8b765b26-6e72-4f75-88aa-ffce03d05137','qysUWz',1,'2023-12-22 17:12:57.074058'),
('8fa68002-767f-49f6-9d60-f7f2bc724210','Oo8bh-',1,'2023-12-22 17:12:28.910233'),
('a67ad9a1-1cdb-4aef-a993-0eccfa3e1b75','soTY81',1,'2023-12-20 11:22:57.337965'),
('cc587055-87e8-4a76-a133-0fb2dc980c81','1maX-J',0,'2023-12-15 09:28:30.693781'),
('d0d0fdf1-6473-4905-bbd5-c19d3d7583f0','kCDk2x',1,'2023-11-14 13:39:17.431264'),
('e043e3a1-7374-4ca1-919a-9f4518e7eab1','y8QI9w',1,'2023-12-22 17:13:22.497225'),
('fae60ee5-592e-4c8e-b03e-ec87701bf018','56pta4',0,'2023-12-20 11:01:48.563424');
/*!40000 ALTER TABLE `activations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `grade` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `review` int(11) DEFAULT 0,
  `rate` float(8,2) DEFAULT 0.00,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `courses_subject_foreign` (`subject`),
  KEY `courses_grade_foreign` (`grade`),
  CONSTRAINT `courses_grade_foreign` FOREIGN KEY (`grade`) REFERENCES `grades` (`id`),
  CONSTRAINT `courses_subject_foreign` FOREIGN KEY (`subject`) REFERENCES `subjects` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES
('0bfd1976-20aa-48fa-ac51-e0b6e755803e','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/QDn8E6b9mDVyZ_g5ncnRV.png',0,0.00,'2023-12-22 10:34:05.726046'),
('0ecdd996-67d7-486c-b392-b53a7c61c428','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','./uploads/images/course/ok5Ie_NdrOMZUGI7VS7jO.png',0,0.00,'2023-12-20 11:11:16.570080'),
('1f881157-25d0-438f-9e70-f22320975084','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/D4OnV4vG2isrGjKkoKoIC.png',0,0.00,'2023-12-20 13:27:17.272404'),
('2086cdf0-d0f2-41bb-8619-2a192026d21e','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/LlMHP6nTyJ5sbuwacc41b.png',0,0.00,'2023-12-20 13:36:34.213552'),
('26b544ef-8eb0-4c7e-a2b8-6a03fb2a6fa4','63ee3377-6527-4d72-ab21-ef73d237596b','b9c1d744-c736-4cba-9350-69fc46d1f74f','/root/Projects/E-learning/src/controllers/uploads/images/course/auNbTIfA-62e9q3WQUHZv.jpeg',0,0.00,'2023-12-20 08:45:08.786813'),
('3e5927e4-7b12-4bbe-b243-243e547abee7','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/coursewOPA8HnP9CwluOvPKKPlE.png',0,0.00,'2023-12-20 14:05:15.669553'),
('538212aa-802f-4a86-bacb-1ec244f42ef0','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/c4vmppqPx610q8D0G5-Mg.png',0,0.00,'2023-12-20 02:33:16.293486'),
('583b836f-396f-4896-a7b0-3441cf7fe64f','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/_gCn-Ye35keLLyQNhzfAj.png',0,0.00,'2023-12-20 02:32:36.479143'),
('59d67685-8e00-470f-b487-9da7bdd01179','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/E-learning/src/controllers/uploads/images/course/-yAi-Lpyp-q1eygSJ73t8.png',0,0.00,'2023-12-20 07:26:17.718773'),
('61b09ea2-6229-4b53-91d6-5c1a07a68558','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/S9MOAYDD8RC6L9sApl-AA.png',0,0.00,'2023-12-20 06:12:23.857991'),
('6ae540ef-2669-4d64-b961-bbc70a60618c','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/g64V9wXD6mOXwi34b8oS2.jpeg',0,0.00,'2023-12-20 02:03:27.921375'),
('6e333a89-a8ac-4b49-bc0b-2f7f471455c9','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','./uploads/images/course/2ZcA1zwOCSk3TJxLgBOct.png',0,0.00,'2023-12-20 13:12:54.237642'),
('6fbfefc3-fbc2-449f-b681-c82a6854ab51','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/cQwZWKCDTydpAdB724Nji.png',0,0.00,'2023-12-20 03:03:52.989166'),
('7004b038-f946-4932-8060-cacc25f49bd3','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/OJIwrPz9kbhc8sEOiDxaD.png',0,0.00,'2023-12-20 02:13:13.772316'),
('71aa8719-cf91-4e0f-9972-815d460a4311','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/_uqVkWfG_UqAATvg7PPb8.png',0,0.00,'2023-12-20 06:58:01.186495'),
('745b83c9-9155-4072-aa6b-1ae9890692e9','63ee3377-6527-4d72-ab21-ef73d237596b','9ba4c44f-fac3-40a0-bd0b-a1586aa1fa3c','./uploads/images/course/kDz5D_T8mtKTFnaVmQtTH.png',0,0.00,'2024-01-08 09:52:55.062934'),
('745dac16-2dd4-4427-bc3b-6fcf2dbe727e','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/E-learning/src/controllers/uploads/images/course/ot5EOf43FCFajr95uEKtK.png',0,0.00,'2023-12-20 07:22:52.868089'),
('7525cfed-7b29-4c5b-a7ef-b093961896e7','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/E-learning/src/controllers/uploads/images/course/W7mPu6brJYwNhYXAUAKDo.png',0,0.00,'2023-12-20 07:32:45.102329'),
('77f55d88-6307-4aaf-872b-65a395e2e43f','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/ZhzX4qxQKUU8T9-K7KrSY.png',0,0.00,'2023-12-20 06:33:10.928535'),
('7befca0d-3046-4e7a-8a10-b6af41c6149f','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/AiFNSpnB6wYXunNTwGgC9.png',0,0.00,'2023-12-20 06:39:25.617681'),
('7f7f5e43-c2a7-412f-9834-025883ea7580','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/OweyvlkpW5szDe8SRatO6.png',0,0.00,'2023-12-20 02:32:48.559614'),
('86f868cb-e0ff-400f-9ac0-685907a48487','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','./uploads/images/course/BoUiIrTEu799JuX5_TZbA.png',0,0.00,'2023-12-20 11:20:44.400000'),
('8eaf431d-ba8b-48fd-94d2-85e1382e72d5','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/RQaf_DUKjK6__hxh4Sd3v.jpeg',0,0.00,'2023-12-20 01:46:47.121045'),
('97491a42-b427-472d-bf3c-2fe0a5e5fb12','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/2rttiLu9qL7ArkbsgEysy.jpeg',0,0.00,'2023-12-20 01:40:09.632596'),
('ad6f573e-61f4-4984-9cb2-1bafa0d797f8','63ee3377-6527-4d72-ab21-ef73d237596b','9ba4c44f-fac3-40a0-bd0b-a1586aa1fa3c','./uploads/images/course/hWd4mnhEuJ3VutGHhy02x.png',0,0.00,'2024-01-08 12:27:31.827076'),
('aedb205e-810d-424d-8afd-006be81a3809','63ee3377-6527-4d72-ab21-ef73d237596b','9ba4c44f-fac3-40a0-bd0b-a1586aa1fa3c','./uploads/images/course/bMEPXGUahSX1fjuA61viq.png',0,0.00,'2024-01-08 10:10:30.742810'),
('aeec34e4-593d-4752-bb75-5cf2978e2189','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/lb7A96Vzd0NKti0hogBCE.png',0,0.00,'2023-12-20 02:39:30.375671'),
('b856fc75-5daf-448f-a601-a010ff0569a0','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/nHfu8AsC5NihTH__-TUnE.png',0,0.00,'2023-12-20 14:15:24.335850'),
('c5be397b-35c5-4461-9322-caa67c7fe11a','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/E-learning/src/controllers/uploads/images/course/rlgX4sBoGNuI4pKd8n21I.png',0,0.00,'2023-12-20 07:41:26.568031'),
('cbef594a-aa95-43e1-b268-22c0337db85a','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/_MEF75lK9IV6LvlnMps3G.png',0,0.00,'2023-12-20 02:17:04.279075'),
('d526f23c-3085-4ffb-860e-9b3ed74d0fd0','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/lum163CC3Z6KC_vbGRyg0.png',0,0.00,'2023-12-20 07:10:59.013062'),
('d557cc00-be43-4775-abdf-72ab8736190a','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/8YXjFL6Wmt8U8KCzYmgub.png',0,0.00,'2023-12-20 07:05:05.722232'),
('d9f250c0-a0af-4f5f-b4b0-10518162f4cc','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','./uploads/images/course/PUwDrR_QHp22tYFOZ_3AJ.png',0,0.00,'2023-12-20 11:22:06.041125'),
('da1829cc-225b-46a7-9c6d-72d54b89f6eb','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','./uploads/images/course/DmGtuGvuEAqGQfumZna8R.png',0,0.00,'2023-12-20 13:19:07.741390'),
('f508d45e-8663-440b-ba1a-07ef485421a1','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/root/Projects/E-learning/src/controllers/uploads/images/course/QzYEGIc_H3UxLZKs2y5-z.png',0,0.00,'2023-12-20 06:14:48.135285'),
('fd0b272c-6c59-45cc-9883-4cec000209ec','fa26d97b-768f-4887-a2e7-9b9e81beae36','1ec46fb6-865f-4b8e-855f-8d336d5e672d','/uploads/images/course/--aDHbwmSn3WYFff0AgS9.jpeg',0,0.00,'2023-12-20 02:03:06.987528');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grades`
--

DROP TABLE IF EXISTS `grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grades` (
  `id` varchar(255) NOT NULL,
  `level` varchar(255) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grades`
--

LOCK TABLES `grades` WRITE;
/*!40000 ALTER TABLE `grades` DISABLE KEYS */;
INSERT INTO `grades` VALUES
('1ec46fb6-865f-4b8e-855f-8d336d5e672d','Basic 2','2023-11-14 14:02:33.184674'),
('245faaab-8aad-408e-bb11-253b27ec3c36','Nursery 2','2023-11-14 14:02:24.465107'),
('63fb4250-e2b4-4781-8da4-6633447d102a','Basic 4','2023-11-14 14:02:42.265263'),
('9ba4c44f-fac3-40a0-bd0b-a1586aa1fa3c','Basic 3','2023-11-14 14:02:37.645088'),
('b9c1d744-c736-4cba-9350-69fc46d1f74f','Basic 1','2023-11-14 14:02:29.164064'),
('fa78dd92-1c76-4057-bcc8-613b03cb2ddb','Basic 5','2023-11-14 14:02:16.518665');
/*!40000 ALTER TABLE `grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructors`
--

DROP TABLE IF EXISTS `instructors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instructors` (
  `id` varchar(255) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `profilePic` varchar(255) DEFAULT NULL,
  `review` int(11) DEFAULT 0,
  `gender` enum('male','female') DEFAULT NULL,
  `rate` float(8,2) DEFAULT 0.00,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructors`
--

LOCK TABLES `instructors` WRITE;
/*!40000 ALTER TABLE `instructors` DISABLE KEYS */;
INSERT INTO `instructors` VALUES
('48474de6-29fa-4de7-ac0c-79fb0c716609','Raakihbull','Hassan','jhdfksjksmmkdjs',1,'male',5.00,'2023-11-14 14:06:45.215067');
/*!40000 ALTER TABLE `instructors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lessons`
--

DROP TABLE IF EXISTS `lessons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lessons` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `instructorName` varchar(255) DEFAULT NULL,
  `instructorPic` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `duration` float(8,2) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `lessons_course_foreign` (`course`),
  CONSTRAINT `lessons_course_foreign` FOREIGN KEY (`course`) REFERENCES `courses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lessons`
--

LOCK TABLES `lessons` WRITE;
/*!40000 ALTER TABLE `lessons` DISABLE KEYS */;
INSERT INTO `lessons` VALUES
('06164a35-467a-43cb-9294-323f83fc16c6','Quadratic Equation Problem','fd0b272c-6c59-45cc-9883-4cec000209ec',' ','Yan Gui','/uploads/images/instructor/','/uploads/videos/lesson/Mf6UU3-QWOBgblGj29Qri.mp4',4.00,'2023-12-20 10:19:53.520125'),
('68348067-97c7-4eda-b0b7-c89c48c6ddc0','Quadratic Equation Problem','fd0b272c-6c59-45cc-9883-4cec000209ec',' ','Yan Gui','/uploads/images/instructor/','/uploads/videos/lesson/JjijHsw-w81V1aL3h6t-6.mp4',4.00,'2023-12-20 10:20:11.048121'),
('d42589b8-2522-44f2-8119-7754eec4c902','Quadratic Equation Problem','fd0b272c-6c59-45cc-9883-4cec000209ec','gfghjhgfd','Yan Gui','/uploads/images/instructor/','/uploads/videos/lesson/I9e5guXjUpZ-PRDWZCXyt.mp4',4.00,'2023-12-20 08:52:10.786497');
/*!40000 ALTER TABLE `lessons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES
('63ee3377-6527-4d72-ab21-ef73d237596b','Verbal Reasoning',NULL,'2023-11-14 13:56:25.826263'),
('96ac4f0b-7bbb-484a-9568-880360836bf0','English',NULL,'2023-12-20 08:43:04.544551'),
('979b6026-20fb-4187-8270-f541f9dceb78','Basic Science',NULL,'2023-12-19 04:57:40.428183'),
('c2419541-5acb-4f2f-bf1d-67326d8e67a3','Quantitative reasonings','Quantitative reasoning is an aptitude subject to enhance kids numerical, logical, and mathematical reasoning','2023-11-14 13:56:46.745468'),
('fa26d97b-768f-4887-a2e7-9b9e81beae36','English Language',NULL,'2023-12-19 04:57:23.939294'),
('fa7ec109-0140-4eb4-903f-ca4fd7085f7b','Mathematics',NULL,'2023-11-14 13:57:07.274184');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tests` (
  `id` varchar(255) NOT NULL,
  `question` varchar(255) DEFAULT NULL,
  `optionA` varchar(255) DEFAULT NULL,
  `optionB` varchar(255) DEFAULT NULL,
  `optionC` varchar(255) DEFAULT NULL,
  `optionD` varchar(255) DEFAULT NULL,
  `answer` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `lesson` varchar(255) DEFAULT NULL,
  `duration` float(8,2) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `tests_lesson_foreign` (`lesson`),
  CONSTRAINT `tests_lesson_foreign` FOREIGN KEY (`lesson`) REFERENCES `lessons` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tests`
--

LOCK TABLES `tests` WRITE;
/*!40000 ALTER TABLE `tests` DISABLE KEYS */;
/*!40000 ALTER TABLE `tests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usercourses`
--

DROP TABLE IF EXISTS `usercourses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usercourses` (
  `id` varchar(255) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `lessons` varchar(255) DEFAULT NULL,
  `status` enum('inprogress','completed') DEFAULT NULL,
  `progress` int(11) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `usercourses_user_foreign` (`user`),
  KEY `usercourses_course_foreign` (`course`),
  CONSTRAINT `usercourses_course_foreign` FOREIGN KEY (`course`) REFERENCES `courses` (`id`),
  CONSTRAINT `usercourses_user_foreign` FOREIGN KEY (`user`) REFERENCES `users` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usercourses`
--

LOCK TABLES `usercourses` WRITE;
/*!40000 ALTER TABLE `usercourses` DISABLE KEYS */;
/*!40000 ALTER TABLE `usercourses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(255) NOT NULL,
  `userId` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `isAdmin` tinyint(1) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `grade` varchar(255) DEFAULT NULL,
  `profilePic` varchar(255) DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `code` varchar(255) DEFAULT NULL,
  `verify` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_userid_unique` (`userId`),
  KEY `users_grade_foreign` (`grade`),
  CONSTRAINT `users_grade_foreign` FOREIGN KEY (`grade`) REFERENCES `grades` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
('0a13701c-d353-45a8-b78d-0cc666b2a0a1','2990944','$2b$10$OFjL9.DOrjR/XRsHEZS40eWDsAPdu6IdF1qAKhKYUzSE6TbL/siZ6','Aje','Dammy','Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-20 10:41:16.941700','',NULL),
('0aa8ca2d-b6c0-464e-a4c0-7c0772d032c3','654536','$2b$10$.WhA6tLmK4B6sHqicrSv6eEcsK/BlKqohzRD8EQamOy7GSpQvw1nm',NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-14 14:48:03.136522',NULL,NULL),
('0c2c660b-ddae-4d47-a67c-c6d378ca6def','8333484',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 17:20:45.282920','o1ig4f',NULL),
('1671b974-82ba-4897-80cb-7d43f4cf45d1','654535','$2b$10$D9eTrD76dtBloV0FWNlAvuo7AHNNT3HmkMZQy9ghMOlNLr8h5Az12',NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-14 14:47:55.980196',NULL,NULL),
('1688e1b8-1b5a-4e50-b164-c6b7c2deb1f9','5387058','$2b$10$otL0B.3uJuYkNmYMO0ARsOErYOPQeoQWKWPj6OeE2fdKhPXEoUKS.','Aje','Damilola','Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-20 10:18:03.163987','',NULL),
('1779046b-7f57-46bb-a4d7-1fdc0c93adfa','6429173','$2b$10$io1U/emjls6eCc5rU75xnOaOVA/iAqUvSrD7OAgnoj7.IAJCV0vwG','James','Abdul','Lagos',NULL,NULL,'male','2013-05-20',NULL,NULL,'2023-12-20 11:32:28.276447','',NULL),
('18ae8444-5fb8-4055-8052-e25246a1dc17','5991356',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-20 07:37:47.809259','9pd95q',NULL),
('1c5637e8-440a-4c86-8d5f-99f2b57a99e3','1955381',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 17:12:52.958694','qnoqs5',NULL),
('1d5a397b-a323-4f6b-aec4-821462efce5d','654531QMMASAXXAYUUM','$2b$10$Sy3soqLGgDrbMbx2JiBqa.J3./YmMetx3KDba4kAkxu76eQMjEvGW',NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-18 20:42:49.340139',NULL,NULL),
('20af8b5e-cddf-4afe-b209-62a0694de00c','2290005','$2b$10$BWFzsvtEuta5kOq.BG3.TOjx.GKdsCJwD2QpG/tebNe2jG/Km2a3y','Aje','Dammy','Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-20 10:41:38.059967','',NULL),
('23808c90-7405-45f9-be30-3fcf941976f3','654531QMMASAXXAYUU','$2b$10$l1As8h3t62Rk/Eu/kZ6oROi5Buy9cTttS.EdXjH03sz0HHaVBrvkW',NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-18 19:20:06.170623',NULL,NULL),
('27cc356c-9cf0-445e-910a-b67cc198eea9','2895046',NULL,NULL,NULL,'Abuja',NULL,NULL,'male','1999-01-01',NULL,NULL,'2023-12-19 02:05:48.715230','qyrmrq',NULL),
('2844b35f-eaf0-4a4a-9d5b-dcaae065e9e5','5854212',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-18 23:38:11.770866','r_mcod',NULL),
('29afa079-d070-4328-bf0e-237745584703','3336917',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 04:37:48.122162','je9rav',NULL),
('2dc6c4b0-a09b-4284-b7f9-2d18f247ef9e','5489212','$2b$10$JPzINM8PcmsusK6yTGBjQeFi50mHnXmkLJmA3lKSVTaIoh1iNwlSm','Aje','Damilola','Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-22 19:54:10.002306','',NULL),
('333e7208-595a-42b4-8472-f197de9d0bee','10007','$2b$10$UfRnhy.k4aj/pB2IcfxX/ei0C45HbTa2R4SIRrTaS1vH3YOGyb9yu',NULL,NULL,'Abuja',NULL,NULL,'male','1999-01-01',NULL,NULL,'2023-12-18 16:38:13.339932',NULL,NULL),
('347e66e0-ed4d-4f9c-9ed9-e1950e2391b6','455447','$2b$10$3sMY0nSrsgDTP1eEPenQ6uQ2sNS/JPJXVVRmc9k2EmUuqKZU22X.C',NULL,NULL,NULL,1,'admin@e-learning.com',NULL,NULL,NULL,NULL,'2023-12-04 10:37:23.445239',NULL,NULL),
('39514925-1f69-4306-8e4a-43dd72e753d2','11223344','$2b$10$thyChkIwkPVgrhZXOSeRSeR0GSVfEYHEdaFRFPvSrWQG5gx1EowG.',NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-18 17:36:09.286958',NULL,NULL),
('3e3a967f-65e4-4750-b1d8-ab3b58435fda','987654','$2b$10$JUrtcXvEIv3AcXkZeW2e8e80FdFzlCMQtZZNf5SfWeH0CjGuvCVXu',NULL,NULL,'Abuja',NULL,NULL,'male','1999-01-01',NULL,NULL,'2023-12-18 16:36:04.647046',NULL,NULL),
('40dddafe-b9df-4b65-ad80-f9c9acd8d757','3444922',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-19 20:34:44.263155','xqauie',NULL),
('44ec66c0-d379-4791-99e5-5178ac3b8404','0737706',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 14:17:00.752496','knp69r',NULL),
('478b6218-64ac-4eb1-8c15-bd0e6e5542b5','7183435',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 17:26:18.079921','2b8r8y',NULL),
('4a0be9a4-771e-4860-9804-09e64c29a865','8189190',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 07:30:02.013518','0lw_jn',NULL),
('4eb2a8f5-4686-4b98-93dd-41535e251fae','8853608','$2b$10$MACzIDYAgj1XqzItrpOmaOx0XuMG74D9PbuDQVk.R6f1EvlESp9Ta','Femi','Ademola','Lagos',NULL,NULL,'male','2010-06-14',NULL,NULL,'2023-12-22 15:33:53.203568','',NULL),
('5b339da8-0135-4ec3-af7e-206fc4ec5532','3973136',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-19 03:17:14.336660','lu3ni4',NULL),
('5e1351e8-e9c6-421f-a824-0ebcc40ca1a1','10008','$2b$10$TNdznbKxqlqq5rNekDERt.6FT7.zESM885clYfo2z03zkgTAW0xDq',NULL,NULL,'Abuja',NULL,NULL,'male','1999-01-01',NULL,NULL,'2023-12-18 17:35:48.611997',NULL,NULL),
('613a2fca-e447-4821-8add-dfa8cf73e262','1501273','$2b$10$YaUqAv0tpgxi.lIwwlk9..T3bDGOVhBoL0KImhBmU2wuykXmPbrJ.','Zully','Folly','Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-20 10:19:29.271070','',NULL),
('6181d47e-f8f4-428c-8c59-86c3fb3639f6','9465978','$2b$10$INixlVZsfrmncee/6Ad.u.TRzMuMMSAJFtqYCR7ywiHKw9XdDhO7u','Aje','Damilola','Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-20 10:38:15.286817','',NULL),
('635a6b1c-54c6-48c8-af8a-a9e67062afde','654531Q','$2b$10$0gtitFlO9Q8SH2m68SsLPOdP53oBeiLA0935xbyJf/KCzRUrgudly',NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-18 22:19:38.076684',NULL,NULL),
('69dd834f-1fed-4ea1-a687-a9021bdae194','12123456','$2b$10$YuHbXh6id7P5Oj5aeaxXQu..tViqfC5c5o1L3c7jal9pfq818MXS.','Aje','Damilola','Abuja',NULL,NULL,'female','1999-01-01',NULL,'/uploads/images/user/','2023-12-15 09:47:50.747467',NULL,NULL),
('7187d39b-eb18-4ee5-9b28-3cda93be89ba','5600926',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 17:27:57.297880','8rs6dt',NULL),
('75a68971-6d8e-4c74-81cf-540164632647','8369963',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-18 23:18:23.621351','gb0zfm',NULL),
('7756d3ef-f872-4994-9538-b16bfa102bcc','8937092',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 09:35:53.311842','h1vyvq',NULL),
('7a54903f-2916-4f89-a53c-f884375cd7d8','1910455','$2b$10$.5peMAAbAbbdfxScGmITk.rOetsKQViziPydqFCQVarW9KBaHRirq','Aje','Damilola','Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-22 15:02:13.629302','',NULL),
('7b0dbacb-3900-4620-9c9b-ec21c5c8bc2d','4122975','$2b$10$rNbx051a0auW3YIRfzThuuTZuaIFoeuCW7.x0AJaAgxv/bCFT30X6','Aje','Damilola','Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-20 11:02:16.912754','',NULL),
('7f0ac5bc-67c1-4ed6-9621-19e940e99142','8850117','$2b$10$87oFPrv8ojW8JetTw/atau6uJVyqOTYKTD5IA2AI6nSJy3bQaK8/G','Aje','Dammy','Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-20 10:37:27.810236','',NULL),
('825e6a14-767d-435c-9d81-caa177b82872','8827959','$2b$10$a6h4LmFn0BmQXhLMA/Gy1eXySzDbwv3XKGykA2l23TfhM0W.hTYGC','Aje','Dammy','Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-20 10:37:14.031156','',NULL),
('83d7c6f6-57b3-45fd-bd56-e9734519c3ed','8764168','$2b$10$PPZKh6//O3u69uhLY66nGOth6X8ist1SGu0Qnz2iPrbLeZ3I1fEdG','Aje','Dammy','Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-20 10:40:34.867259','',NULL),
('86201fbf-96f8-4fd8-b62d-6755f6ec3302','654531QMMASA','$2b$10$SZBIkmnNnLTO6yazpdspVuD5QEpNIpITngVLSuctxi4nYZiiNH7F.',NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-18 17:15:16.518781',NULL,NULL),
('864887fd-1b6a-41b3-92bb-8234b59adf20','8338188',NULL,NULL,NULL,'Abuja',NULL,NULL,'male','1999-01-01',NULL,NULL,'2023-12-19 02:02:08.423721','ta0d7v',NULL),
('87b615a0-bc4b-4ad6-a91e-b92a7d4075b4','2005','$2b$10$fceuAfVrU5HVHBFOqJLCd.0YDshVrvui131JStf5totQUH2HxlwA.','Aje','Damilola','Abuja',NULL,NULL,'male','2005-05-25',NULL,'/uploads/images/user/','2023-12-15 10:33:13.492354',NULL,NULL),
('8aa4a9d8-bf93-459e-aa6a-c8a70d75ddad','7796894',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 10:58:17.755509','sis_gy',NULL),
('8ddcbe14-c4b8-4700-959f-ce3295d27770','5682041','$2b$10$OAuiKBXI4JdaLAurabyOzeuMundtaUfoo.0S/Z2c0bFvVHWOxUmam','Net-Trix','Solutions ','Lagos',NULL,NULL,'male','1999-05-01',NULL,NULL,'2023-12-22 17:22:45.688297','',NULL),
('90623d6a-a3c3-4d65-896c-022a533a1f3c','4281989','$2b$10$Ty.MXi2Zu9/nHRcPqxqoBebvT5PaoWd5GBabUuRt8XMTS.4HRu57S','Aje','Damilola','Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-20 10:17:42.585323','',NULL),
('91fcf71f-1561-4baf-ab95-7632ba74bff0','1483466','$2b$10$PPLhYBFR.IDuZsD0cIdK5ulqI7MAzquOFoR10G7bcMERa0lTeRjOi','Aje','Damilola','Anambra',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-20 10:44:16.931449','',NULL),
('938a58f5-d76f-4081-b35c-b9fd3dd6ca91','9345304','$2b$10$yZIyKnJH/m1SJBuApfaEuuemH7SAHM9RQQpyim3ke8vF81IvjW8vu','John','Dor','Abia',NULL,NULL,'female','2111-08-08',NULL,NULL,'2023-12-22 11:26:06.086895','',NULL),
('99288780-266d-49b8-b7ed-cc452e98622a','1380132',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-18 23:27:43.797448','2qiq04',NULL),
('9a195edd-09bd-458d-9479-80d0a0133dac','654531QMMASAXXAY','$2b$10$6WIaO5MnHuOyjzgzBozQmObd2RJSjVN1DRlPzJJ.p1XEUBZoG86r2',NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-18 17:17:05.292597',NULL,NULL),
('9e1ccc5a-64f6-49a5-bf56-46cdb6512d1a','0646368',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-20 10:09:21.137123','pu3axj',NULL),
('a195ca21-63ce-4c31-aaa9-8692ec70bbd4','654534','$2b$10$1xQ0zydUtIEUnX0Cm/xyfeltaaLyhpWY3PJXP8F587XMNEZuM/quO',NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-14 14:47:34.963361',NULL,NULL),
('a5c4b00d-c90b-46d7-a8f7-8e3e34ca278a','7369459',NULL,NULL,NULL,'Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-20 09:25:31.490749','pipynk',NULL),
('ab7e3ddc-6131-4896-9fbb-eb9434eee565','5946557',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-19 01:24:55.973708','0dpisx',NULL),
('abb8d62b-49df-4ad7-b5a4-cfb4897e50a2','5289038',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','2007-08-11',NULL,NULL,'2023-12-19 03:58:43.629091','3yy9aq',NULL),
('acb31db2-4cec-4dae-81d1-51da2586e77b','654531QMM','$2b$10$3Ivg1HuYmZuWfZDC.3jDs.o4O.8h/FiUcXNtv4MsIBh672.Er0S1i',NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-18 15:44:26.476502',NULL,NULL),
('af75a75a-f58e-400a-8a8a-5dc6e3344056','2318239',NULL,NULL,NULL,'Abia',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-20 09:25:24.419890','yidoix',NULL),
('b4e91b35-26f7-4570-a19a-11f49e7b9607','1864984',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 11:05:33.765906','hp8x1b',NULL),
('c0d65aab-d78d-4fb5-8e50-56e9e6ff9078','4154921',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-19 18:39:07.470200','b1hmkg',NULL),
('c404ba5f-1912-44d2-8d75-a2ad85cac9a9','3729646',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 11:42:56.813413','z3tg1h',NULL),
('c7d9c85f-f04b-4698-8b10-ff96a6ed8db9','1234567','$2b$10$afW/VmJr87.sTYDe8DwMFeHHnHQBhiN53ynhw4cviObATXMH3N1be',NULL,NULL,'Abuja',NULL,NULL,'male','1999-01-01',NULL,NULL,'2023-12-18 16:35:46.224855',NULL,NULL),
('ca77a564-37dd-451f-ae92-ab5d0d0cb318','9498895',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 17:29:23.542789','8qfmdc',NULL),
('caff10cc-c3eb-4bed-ad2b-383e309c62fa','3383928',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-25',NULL,NULL,'2023-12-18 23:10:38.692454','kgztzu',NULL),
('cc352b00-f09d-4380-9b15-7540e9a75e39','0000921',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 02:28:15.216254','s4optr',NULL),
('d21bb0d2-3e71-4db6-9c20-0b7969d63bd7','7042116',NULL,NULL,NULL,'Abuja',NULL,NULL,'male','1999-01-01',NULL,NULL,'2023-12-19 11:55:42.684092','aqyrfy',NULL),
('dc67343c-46e6-4e86-9f21-5f82b6ffe4bb','1714894',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-19 17:13:54.804550','g28udw',NULL),
('de8eb1cc-d5fa-4351-8636-6f2a0667f81c','12345','$2b$10$vjx9Vjx7XdGcmq03j9pmVeGLEwhZ1sKpZRLoPrI6ye602DenMNrl.',NULL,NULL,'Abuja',NULL,NULL,'male','1999-01-01',NULL,NULL,'2023-12-18 16:35:37.341812',NULL,NULL),
('ee01a3c0-9dc9-4b08-be2d-b4fa3f6c1b6e','3422086',NULL,NULL,NULL,'Abuja',NULL,NULL,'female','2120-06-08',NULL,NULL,'2023-12-19 17:44:38.827955','p5cip1',NULL),
('f4305b50-bac6-4914-b75c-ca8958c426a4','112233445','$2b$10$dEcDgtHAbqQQ4b8PPUU0SuutVfPWuWnqGB6to4Xg.pGMlNkUziuwi',NULL,NULL,'Abuja',NULL,NULL,'female','1999-01-01',NULL,NULL,'2023-12-18 18:56:20.601069',NULL,NULL),
('fb68e01c-5dfb-434b-bb63-277a4b42d883','8171180',NULL,NULL,NULL,'Lugbe, Abuja',NULL,NULL,'male','1995-11-22',NULL,NULL,'2023-12-19 18:35:06.409649','bd5-dc',NULL),
('fe303dcd-0f80-43a1-ac06-48dac39c2c5e','3399044',NULL,NULL,NULL,'Abuja',NULL,NULL,'male','2010-01-01',NULL,NULL,'2023-12-19 10:58:29.978050','_6oloy',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usertests`
--

DROP TABLE IF EXISTS `usertests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usertests` (
  `id` varchar(255) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `lesson` varchar(255) DEFAULT NULL,
  `tests` varchar(255) DEFAULT NULL,
  `score` float(8,2) DEFAULT NULL,
  `status` enum('inprogress','completed') DEFAULT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `usertests_user_foreign` (`user`),
  KEY `usertests_lesson_foreign` (`lesson`),
  CONSTRAINT `usertests_lesson_foreign` FOREIGN KEY (`lesson`) REFERENCES `tests` (`lesson`),
  CONSTRAINT `usertests_user_foreign` FOREIGN KEY (`user`) REFERENCES `users` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertests`
--

LOCK TABLES `usertests` WRITE;
/*!40000 ALTER TABLE `usertests` DISABLE KEYS */;
/*!40000 ALTER TABLE `usertests` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-08 13:00:16
